﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        public string UserNameOnMasterPage
        {
            get
            {
                // Get value of control on master page  
                return lblMasterPageUser.Text;
            }
            set
            {
                // Set new value for control on master page  
                lblMasterPageUser.Text = value;
            }
        }  
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}