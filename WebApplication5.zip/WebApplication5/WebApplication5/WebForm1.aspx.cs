﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    class State
    {
        public string StateName { get; set; }
        public string StateCode { get; set; }
    }
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                List<State> lstState = new List<State>();
                State st1 = new State();
                st1.StateName = "Jharkhand";
                st1.StateCode = "JH";

                State st2 = new State();
                st2.StateName = "Bihar";
                st2.StateCode = "BH";

                State st3 = new State();
                st3.StateName = "Maharastra";
                st3.StateCode = "MH";

                lstState.Add(st1);
                lstState.Add(st2);
                lstState.Add(st3);

                ddlState.DataSource = lstState;//source of data from where drop list will be bind
                ddlState.DataTextField = "StateName";//name of the property to shown in dropdown list
                ddlState.DataValueField = "Statecode";//value for the corresponding state
                ddlState.DataBind();//actually binds the data

                ddlState.Items.Insert(0, "Select");//insert default text select at 0 position
            }
            
        }

        protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
        {
            ((Site1)Master).UserNameOnMasterPage = "Deepak";//method 1 to get/set value to the control of master page
            Label lblCustom = (Label)Page.Master.FindControl("lblCustom");//method 2 to get control
            lblCustom.Text = "Namita";
        }
    }
}